import { HttpClientModule } from "@angular/common/http";
import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { MainPageComponent } from "./mainPage.component";
import { MainPageService } from "./mainPage.service";

@NgModule({
    declarations: [
      MainPageComponent,
    ],
    imports: [
      HttpClientModule,
      BrowserModule,
    ],
    providers: [MainPageService],
    bootstrap: [MainPageComponent]
  })
  export class MainPageModule { }