import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";

@Injectable({providedIn:"root"})
export class MainPageService {
constructor(private http: HttpClient){}

    getType(token: string){
        return this.http.get<any>("http://localhost:8080/user/getUserById/" + token)
    }

    endSemester(){
        return this.http.put<any>("http://localhost:8080/user/updateGPA", null);
    }
}