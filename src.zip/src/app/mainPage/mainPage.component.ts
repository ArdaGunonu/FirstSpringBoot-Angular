import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { MainPageService } from './mainPage.service';
import { StoreService } from '../store.service';

@Component({
  selector: 'main-page-root',
  standalone: true,
  imports: [
    RouterModule,
    HttpClientModule    
  ],
  providers: [
    MainPageService,
    StoreService
  ],
  templateUrl: './mainPage.component.html'
})
export class MainPageComponent {
  constructor(private mainPageService: MainPageService, private storeService: StoreService){}
  type!: string;

  registerIsHidden: boolean = true;
  createUserIsHidden: boolean = true;
  createLectureIsHidden: boolean = true;
  endSemesterIsHidden: boolean = true;
  updateGradeIsHidden: boolean = true;

  ngOnInit(): void {
    this.getType();
  }

  getType(){
    this.mainPageService.getType(this.storeService.getToken()).subscribe((data)=>{
      this.type = data.type;
      this.setHiddens();
    })
  }

  setHiddens(){
    if(this.type == "admin"){
      this.createUserIsHidden = false;
      this.createLectureIsHidden = false;
      this.endSemesterIsHidden = false;
    }
    else if(this.type == "student"){
      this.registerIsHidden = false;
    }
    else if(this.type == "teacher"){
      this.updateGradeIsHidden = false;
    }
  }

  onClickEndSemester(){
    this.mainPageService.endSemester().subscribe((data)=>{})
  }
}
