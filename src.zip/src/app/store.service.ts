import { Injectable } from "@angular/core";

@Injectable({providedIn:"root"})
export class StoreService {
    private static token: string = '';

    clickStore(){
        console.log(StoreService.token);
    }

    setToken(newToken: string){
        StoreService.token = newToken;
    }

    getToken(){
        return StoreService.token;
    }

}