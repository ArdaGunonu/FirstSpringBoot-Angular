import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { CreateUserService } from './createUser.service';
import { StoreService } from '../store.service';

@Component({
    selector: 'app-create-user',
    standalone: true,
    imports: [
        CommonModule,
        ReactiveFormsModule
    ],
    providers: [
        CreateUserService,
        StoreService
    ],
    templateUrl: './createUser.component.html'
  })
  export class CreateUserComponent {
    constructor(private createUserService: CreateUserService, private storeService: StoreService){}
    userForm = new FormGroup({
        name: new FormControl(''),
        lastname: new FormControl(''),
        email: new FormControl(''),
        phone: new FormControl(''),
        type: new FormControl(''),
        password: new FormControl('')
    });

    onClickCreateUser(){
        this.createUserService.createUser(this.userForm.value, this.storeService.getToken()).subscribe((data)=>{})
    }
  }