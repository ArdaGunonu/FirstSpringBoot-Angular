import { HttpClientModule } from "@angular/common/http";
import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { CreateUserComponent } from "./createUser.component";
import { CreateUserService } from "./createUser.service";

@NgModule({
    declarations: [
      CreateUserComponent,
    ],
    imports: [
      HttpClientModule,
      BrowserModule,
    ],
    providers: [CreateUserService],
    bootstrap: [CreateUserComponent]
  })
  export class CreateUserModule { }