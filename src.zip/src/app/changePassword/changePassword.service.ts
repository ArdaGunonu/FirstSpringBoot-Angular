import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";

@Injectable({providedIn:"root"})
export class ChangePasswordService {
constructor(private http: HttpClient){}
    changePassword(passwords: any, token: string){
        return this.http.put<any>("http://localhost:8080/user/changePassword/" + token + "/" + passwords.oldPassword + "/" + passwords.newPassword, null);
    }
}