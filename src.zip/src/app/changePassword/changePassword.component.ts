import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { ChangePasswordService } from './changePassword.service';
import { StoreService } from '../store.service';

@Component({
    selector: 'app-change-password',
    standalone: true,
    imports: [
        CommonModule,
        ReactiveFormsModule
    ],
    providers: [
        ChangePasswordService,
        StoreService
    ],
    templateUrl: './changePassword.component.html'
  })
  export class ChangePasswordComponent {
    constructor(private changePasswordService: ChangePasswordService, private storeService: StoreService){}
    
    passwordForm = new FormGroup({
        oldPassword: new FormControl(''),
        newPassword: new FormControl(''),
        newPasswordAgain: new FormControl('')
    });

    onClickChangePassword(){
        if(this.passwordForm.value.newPassword == this.passwordForm.value.newPasswordAgain){
          this.changePasswordService.changePassword(this.passwordForm.value, this.storeService.getToken()).subscribe((data)=>{
          })
        }
    }
  }