import { HttpClientModule } from "@angular/common/http";
import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { ChangePasswordComponent } from "./changePassword.component";
import { ChangePasswordService } from "./changePassword.service";

@NgModule({
    declarations: [
      ChangePasswordComponent,
    ],
    imports: [
      HttpClientModule,
      BrowserModule,
    ],
    providers: [ChangePasswordService],
    bootstrap: [ChangePasswordComponent]
  })
  export class ChangePasswordModule { }