import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { CreateLectureService } from './createLecture.service';
import { StoreService } from '../store.service';

@Component({
    selector: 'app-create-lecture',
    standalone: true,
    imports: [
        CommonModule,
        ReactiveFormsModule
    ],
    providers: [
        CreateLectureService,
        StoreService
    ],
    templateUrl: './createLecture.component.html'
  })
  export class CreateLectureComponent {
    selectedTeacher: any;
    teacherArray: any;

    constructor(private createLectureService: CreateLectureService, private storeService: StoreService){}
    lectureForm = new FormGroup({
        teacherId: new FormControl(''),
        name: new FormControl(''),
        credit: new FormControl(),
    });

    getTeachers(){
        this.createLectureService.getTeachers(this.storeService.getToken()).subscribe((data)=>{
            this.teacherArray = data;
        })
    }

    ngOnInit(): void {
        this.getTeachers();
      }

    onClickCreateLecture(){
        this.createLectureService.createLecture(this.lectureForm.value, this.storeService.getToken()).subscribe(({data})=>{})
    }
  }