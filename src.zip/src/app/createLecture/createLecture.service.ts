import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";

@Injectable({providedIn:"root"})
export class CreateLectureService {
constructor(private http: HttpClient){}

    getTeachers(token: string){
        let headers = new HttpHeaders().append("token", token);
        return this.http.get<any>("http://localhost:8080/user/getTeachers",{headers})
    }

    createLecture(values: any, token: string){
        let headers = new HttpHeaders().append("token", token);
        return this.http.post<any>("http://localhost:8080/user/createLecture", values, {headers})
    }
}