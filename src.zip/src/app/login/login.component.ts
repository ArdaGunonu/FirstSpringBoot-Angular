import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { LoginService } from './login.service';
import { StoreService } from '../store.service'
import { AppComponent } from '../app.component';
import { Router } from '@angular/router';

@Component({
    selector: 'app-login',
    standalone: true,
    imports: [
        CommonModule,
        ReactiveFormsModule,
        AppComponent,
        RouterModule
    ],
    providers:[
        LoginService,
        StoreService
    ],
    templateUrl: './login.component.html'
  })
  export class LoginComponent {
    constructor(private loginService: LoginService, private storeService: StoreService, private router: Router){}
    loginForm = new FormGroup({
        email: new FormControl(''),
        password: new FormControl('')
    });

    onClickLogin(){
        this.loginService.login(this.loginForm.value).subscribe((data)=>{
            this.storeService.setToken(data.id);
            this.router.navigate(['/mainPage']);
        })
    }
  }