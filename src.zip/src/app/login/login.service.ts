import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";

@Injectable({providedIn:"root"})
export class LoginService {
constructor(private http: HttpClient){}

    login(values: any){
        let headers = new HttpHeaders().append("email",values.email).append("password",values.password)
        return this.http.get<any>("http://localhost:8080/auth/login",{headers})
    }
}