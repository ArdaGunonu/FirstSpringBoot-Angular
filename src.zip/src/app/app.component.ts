import { Component } from '@angular/core';
import { LoginComponent } from './login/login.component';
import { RouterModule } from '@angular/router';
import { initFlowbite } from 'flowbite';
import { HttpClientModule } from '@angular/common/http';
import { StoreService } from './store.service';//token geldi mi diye bak

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    LoginComponent,
    RouterModule,
    HttpClientModule    
  ],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'homes';

  ngOnInit(): void {
    initFlowbite();
  }

}
