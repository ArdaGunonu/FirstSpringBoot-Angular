import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { StoreService } from '../store.service';
import { RegistrationService } from './registration.service';

@Component({
    selector: 'app-registration',
    standalone: true,
    imports: [
        CommonModule,
        ReactiveFormsModule
    ],
    providers: [
        StoreService,
        RegistrationService
    ],
    templateUrl: './registration.component.html'
  })
  export class RegistrationComponent {
    constructor(private registrationService: RegistrationService, private storeService: StoreService){}
    userForm = new FormGroup({
        name: new FormControl(''),
        lastname: new FormControl(''),
        email: new FormControl(''),
        phone: new FormControl(''),
        type: new FormControl(''),
        password: new FormControl('')
    });
    dataObject: any
    lessons!: string[];
    basket: string[] = [];
    nameBasket: string[] = [];

    getLectures(){
        this.registrationService.getLectures(this.storeService.getToken()).subscribe((data)=>{
            this.dataObject = data
            this.lessons = data.map((item: { name: any; }) => item.name);
        })
    }

    ngOnInit(): void {
        this.getLectures();
      }

    addBasket(lectureId: string, name: string){
        if(!this.basket.includes(lectureId)){
            this.basket.push(lectureId);
            this.nameBasket.push(name);
        }
    }

    onClickAddLessons(){
        this.basket.forEach((lectureId) =>{
            this.registrationService.addRecords(lectureId, this.storeService.getToken()).subscribe(({data})=>{
            this.basket.pop;
        })
        })
    }
  }