import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";

@Injectable({providedIn:"root"})
export class RegistrationService {
constructor(private http: HttpClient){}

    getLectures(token: string){
        let headers = new HttpHeaders().append("token", token);
        return this.http.get<any>("http://localhost:8080/user/getLectures",{headers})
    }

    addRecords(lectureId: string, token: string){
        let headers = new HttpHeaders().append("token", token); 
        return this.http.post<any>("http://localhost:8080/user/addRecord", {
            studentId: token,
            lectureId: lectureId
        }, {headers})
    }
}