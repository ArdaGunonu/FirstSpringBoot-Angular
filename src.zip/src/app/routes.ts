import { Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { CreateUserComponent } from './createUser/createUser.component';
import { MainPageComponent } from './mainPage/mainPage.component';
import { RegistrationComponent } from './registration/registration.component';
import { CreateLectureComponent } from './createLecture/createLecture.component';
import { UpdateGradeComponent } from './updateGrade/updateGrade.component';
import { ChangePasswordComponent } from './changePassword/changePassword.component';

const routeConfig: Routes = [
    {
      path: '',
      component: LoginComponent,
      title: 'Home page'
    },
    {
      path: 'createUser',
      component: CreateUserComponent,
      title: 'CreateUser'
    },
    {
      path: 'mainPage',
      component: MainPageComponent,
      title: 'MainPage'
    },
    {
      path: 'register',
      component: RegistrationComponent,
      title: 'RegistrationPage'
    },
    {
      path: 'createLecture',
      component: CreateLectureComponent,
      title: 'CreateLecture'
    },
    {
      path: 'updateGrade',
      component: UpdateGradeComponent,
      title: 'UpdateGrade'
    },
    {
      path: 'changePassword',
      component: ChangePasswordComponent,
      title: 'ChangePassword'
    }
  ];
  
  export default routeConfig;