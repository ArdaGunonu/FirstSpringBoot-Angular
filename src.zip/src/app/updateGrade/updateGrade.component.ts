import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { StoreService } from '../store.service';
import { UpdateGradeService } from './updateGrade.service';
import { FormsModule } from '@angular/forms'; // Import FormsModule

//import { subscribe } from 'diagnostics_channel';

@Component({
    selector: 'app-update-grade',
    standalone: true,
    imports: [
        CommonModule,
        ReactiveFormsModule,
        FormsModule
    ],
    providers: [
        StoreService,
        UpdateGradeService
    ],
    templateUrl: './updateGrade.component.html'
  })
  export class UpdateGradeComponent {
    constructor(private updateGradeService: UpdateGradeService, private storeService: StoreService){}
    gradeForm = new FormGroup({
        grade: new FormControl()
    });
    lectureObject: any;
    lectures!: string[];
    lecturesIsHidden: boolean = false;
    lectureId!: string;
    lectureName!: string;
    recordObject: any;
    allStudents!: string[];
    students: [] = [];
    lastStudent: [] = [];
    studentsIsHidden: boolean = true;
    grade!: number
    
    //basket: string[] = [];
    //nameBasket: string[] = [];

    getLectures(){
        this.updateGradeService.getLectures(this.storeService.getToken()).subscribe((data)=>{
            this.lectureObject = data;
            this.lectures = data.map((item: { name: any }) => item.name);
        })
    }

    onClickChooseLecture(lectureId: string, lectureName: string){
        this.lecturesIsHidden = true;
        this.lectureId = lectureId;
        this.lectureName = lectureName;
        this.studentsIsHidden = false;
        this.getRecords();
    }

    getRecords(){
        this.updateGradeService.getStudents(this.storeService.getToken(), this.lectureId).subscribe((data)=>{
            this.recordObject = data;
            this.students = data.map((item: { studentId: any; }) => item.studentId);
            this.getStudentNames();
        })
    }

    getStudentNames(){
        this.updateGradeService.getStudentNames().subscribe((data)=>{
            this.allStudents = data;
        })
    }

    onClickUpdateGrade(grade: number, studentId: string){
        this.updateGradeService.updateGrade(grade, this.lectureId, studentId).subscribe((data)=>{
        })
    }

    ngOnInit(): void {
        this.getLectures();
      }


    // addBasket(lectureId: string, name: string){
    //     if(!this.basket.includes(lectureId)){
    //         this.basket.push(lectureId);
    //         this.nameBasket.push(name);
    //     console.log(lectureId);
    //     console.log(this.basket)
    //     }
    //     else console.log("exist");
    // }

    // onClickAddLessons(){
    //     //console.log('xxx' + this.storeService.token);
    //     this.basket.forEach((lectureId) =>{
    //         this.updateGradeService.addRecords(lectureId, this.storeService.getToken()).subscribe(({data})=>{
    //         //this.storeService.token = data.id;
    //         console.log(this.basket);
    //         this.basket.pop;
    //         console.log(this.basket);
    //         console.log(data);
    //         console.log('asdad')
    //     })
    //     })
    // }
  }