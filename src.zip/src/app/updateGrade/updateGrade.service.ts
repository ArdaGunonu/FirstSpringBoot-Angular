import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";

@Injectable({providedIn:"root"})
export class UpdateGradeService {
constructor(private http: HttpClient){}

    getLectures(token: string){
        return this.http.get<any>("http://localhost:8080/user/getLecturesByTeacher/" + token)
    }

    getStudents(token: string, lectureId: string){
        let headers = new HttpHeaders().append("token", token);
        return this.http.get<any>("http://localhost:8080/user/getRecordsByLecture/" + lectureId,{headers})
    }

    getStudentNames(){
        return this.http.get<any>("http://localhost:8080/user/getStudents")
    }

    addRecords(lectureId: string, token: string){
        let headers = new HttpHeaders().append("token", token); 
        return this.http.post<any>("http://localhost:8080/user/addRecord", {
            studentId: token,
            lectureId: lectureId
        }, {headers})
        
        
    }

    updateGrade(grade: number, lectureId: string, studentId: string){
        return this.http.put("http://localhost:8080/user/updateGrade/" + lectureId + "/" + studentId, {
            "grade": grade
        });
    }
}