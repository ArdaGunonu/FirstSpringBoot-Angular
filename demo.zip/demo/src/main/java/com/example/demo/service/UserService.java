package com.example.demo.service;

import com.example.demo.entity.Lecture;
import com.example.demo.entity.Record;
import com.example.demo.entity.Student;
import com.example.demo.entity.User;

import java.util.List;
import java.util.Optional;

public interface UserService {

    //START OF USER
    User createUser(User user);
    List<User> getUsers();
    User getUser(String id);
    List<User> getTeachers();
    List<User> getStudents();
    String getType(String token);

    User updateUser(String id, User user);
    String changePassword(String id, String oldPassword, String newPassword);
    Boolean deleteUser(String id);
    //END OF USER

    //START OF LECTURE
    Lecture createLecture(Lecture lecture);
    List<Lecture> getLectures();
    List<Lecture> getLecturesByTeacher(String id);
    Lecture updateLecture(String id, Lecture lecture);
    Boolean deleteLecture(String id);
    //END OF LECTURE

    //START OF RECORD
    Record addRecord(Record record);
    List<Record> getRecordsByLecture(String id);
    List<Record> getRecordsByStudent(String id);
    Record updateGrade(String lectureId, String studentId, Record record);
    Boolean deleteRecord(String id);
    Boolean deleteRecords();
    //END OF RECORD

    //START OF STUDENT
    List<Student> updateGPA();
    //END OF STUDENT
}
