package com.example.demo.controller;

import com.example.demo.entity.Lecture;
import com.example.demo.entity.Student;
import com.example.demo.entity.User;
import com.example.demo.entity.Record;
import com.example.demo.model.LectureModel;
import com.example.demo.model.RecordModel;
import com.example.demo.model.UserModel;
import com.example.demo.service.AuthService;
import com.example.demo.service.UserService;
import org.springframework.beans.BeanUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
public class UserController {

    private final UserService userService;
    private final AuthService authService;

    public UserController(UserService userService, AuthService authService) {
        this.userService = userService;
        this.authService = authService;
    }

    //START OF USER
        @PostMapping("/createUser")
        public ResponseEntity<User> createUser (@RequestBody UserModel userModel){
        User user = new User();
        BeanUtils.copyProperties(userModel, user);
        User resultUser = userService.createUser(user);
        return ResponseEntity.ok(resultUser);
    }

        @GetMapping("getUsers")
        public ResponseEntity<List<User>> getUsers () {
        List<User> users = userService.getUsers();
        return ResponseEntity.ok(users);
    }

        @GetMapping("getUserById/{id}")
        public ResponseEntity<User> getUser (@PathVariable("id") String id){
        //authService.auth();
        User user = userService.getUser(id);
        return ResponseEntity.ok(user);
    }

        @GetMapping("getTeachers")
        public ResponseEntity<List<User>> getTeachers (){
            List<User> users = userService.getTeachers();
            return ResponseEntity.ok(users);
        }

        @GetMapping("getStudents")
        public ResponseEntity<List<User>> getStudents (){
            List<User> users = userService.getStudents();
            return ResponseEntity.ok(users);
        }

        /*@GetMapping("getStudentsByLectures")
        public ResponseEntity<List<User>> getStudentsByLectures(@RequestBody List<String> ids){
            return null;
        }*/

        @GetMapping("getType/{id}")
        public String getType(@PathVariable("id") String token){
            String type = userService.getType(token);
            return type;
        }



        @PutMapping("updateUser/{id}")
        public ResponseEntity<User> updateUser (@PathVariable("id") String id, @RequestBody User user){
        User resultUser = userService.updateUser(id, user);
        return ResponseEntity.ok(resultUser);
    }

        @PutMapping("changePassword/{token}/{oldPassword}/{newPassword}")
        public ResponseEntity<String> changePassword (@PathVariable("token") String id, @PathVariable("oldPassword") String oldPassword, @PathVariable("newPassword") String newPassword){
            String status = userService.changePassword(id, oldPassword, newPassword);
            return ResponseEntity.ok(status);
        }

        @DeleteMapping("deleteUser/{id}")
        public ResponseEntity<Boolean> deleteUser (@PathVariable("id") String id){
        Boolean status = userService.deleteUser(id);
        return ResponseEntity.ok(status);
    }
    //END OF USER

    //START OF LECTURE
        @PostMapping("createLecture")
        public ResponseEntity<Lecture> createLecture (@RequestBody LectureModel lectureModel){
            Lecture lecture = new Lecture();
            BeanUtils.copyProperties(lectureModel, lecture);
            Lecture resultLecture = userService.createLecture(lecture);
          return ResponseEntity.ok(resultLecture);
    }

        @GetMapping("getLectures")
        public ResponseEntity<List<Lecture>> getLectures (){
            List<Lecture> lectures = userService.getLectures();
            return ResponseEntity.ok(lectures);
        }

        @GetMapping("getLecturesByTeacher/{id}")
        public ResponseEntity<List<Lecture>> getLecturesByTeacher (@PathVariable("id") String id){
            List<Lecture> lectures = userService.getLecturesByTeacher(id);
            return ResponseEntity.ok(lectures);
        }

        @PutMapping("updateLecture/{id}")
        public ResponseEntity<Lecture> updateLecture(@PathVariable ("id") String id, @RequestBody Lecture lecture){
            Lecture resultLecture = userService.updateLecture(id, lecture);
            return ResponseEntity.ok(resultLecture);
        }



        @DeleteMapping("deleteLecture/{id}")
        public ResponseEntity<Boolean> deleteLecture (@PathVariable ("id") String id){
            Boolean status = userService.deleteLecture(id);
            return ResponseEntity.ok(status);
        }
    //END OF LECTURE

    //START OF RECORD
        @PostMapping("addRecord")
        public ResponseEntity<Record> addRecord(@RequestBody RecordModel recordModel, @RequestHeader("token") String token){
            Record record = new Record();
            record.setStudentId(token);
            BeanUtils.copyProperties(recordModel, record);
            Record resultRecord = userService.addRecord(record);
            return ResponseEntity.ok(resultRecord);
        }

        @GetMapping("getRecordsByLecture/{id}")
        public ResponseEntity<List<Record>> getRecordsByLecture(@PathVariable ("id") String id){
            List<Record> records = userService.getRecordsByLecture(id);
            return ResponseEntity.ok(records);
        }

        @GetMapping("getRecordsByStudent/{id}")
        public ResponseEntity<List<Record>> getRecordsByStudent(@PathVariable ("id") String id){
            List<Record> records = userService.getRecordsByStudent(id);
            return ResponseEntity.ok(records);
        }

        @PutMapping("updateGrade/{lectureId}/{studentId}")
        public ResponseEntity<Record> updateGrade(@PathVariable ("lectureId") String lectureId, @PathVariable ("studentId") String studentId, @RequestBody Record record){
            Record resultRecord = userService.updateGrade(lectureId, studentId, record);
            return ResponseEntity.ok(resultRecord);
        }

        @DeleteMapping("deleteRecord/{id}")
        public ResponseEntity<Boolean> deleteRecord(@PathVariable ("id") String id){
            Boolean status = userService.deleteRecord(id);
            return ResponseEntity.ok(status);
        }

        @DeleteMapping("deleteRecords")
        public ResponseEntity<Boolean> deleteRecords(){
            Boolean status = userService.deleteRecords();
            return ResponseEntity.ok(status);
        }
    //END OF RECORD

    //START OF STUDENT
        @PutMapping("updateGPA")
        public ResponseEntity<List<Student>> updateGPA(){
            List<Student> students = userService.updateGPA();
            return null;
        }
    //END OF STUDENT
}
