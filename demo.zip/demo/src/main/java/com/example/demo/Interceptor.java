package com.example.demo;

import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import java.util.Optional;
//import org.springframework.web.servlet.HandlerInterceptor;
//import org.springframework.web.servlet.ModelAndView;

@Component
public class Interceptor implements HandlerInterceptor {

    @Autowired
    UserRepository userRepository;

    /*@Override
    public void postHandle(
        HttpServletRequest request, HttpServletResponse response, Object handler,
        ModelAndView modelAndView) throws Exception {
            if(!request.getRequestURL().toString().contains("login")){
                String token = request.getHeader("token");
                Optional<User> user = userRepository.findById(token);

                if(!user.isPresent()) throw new RuntimeException("Your mail or password is wrong!");

                if(request.getRequestURL().toString().contains("addRecord") ||
                   request.getRequestURL().toString().contains("deleteRecord") ||
                   request.getRequestURL().toString().contains("changePassword") ||
                   request.getRequestURL().toString().contains("getLectures")){
                    if(!user.get().getType().equals("student")) throw new RuntimeException("You are not student");
                }

                else if(request.getRequestURL().toString().contains("upgradeGrade")){
                    if(!user.get().getType().equals("teacher")) throw new RuntimeException("You are not teacher");
                }

                else {
                    if(!user.get().getType().equals("admin")) throw new RuntimeException("You are not admin");
                }
            }
    }*/
}
