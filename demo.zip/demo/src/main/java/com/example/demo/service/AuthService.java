package com.example.demo.service;

import com.example.demo.entity.User;

import java.util.Optional;

public interface AuthService {



    Optional<User> login(String email, String password);
    //void auth();
}
