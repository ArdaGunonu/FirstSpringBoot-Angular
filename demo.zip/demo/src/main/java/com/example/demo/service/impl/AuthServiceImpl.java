package com.example.demo.service.impl;

import com.example.demo.entity.User;
import com.example.demo.repository.LectureRepository;
import com.example.demo.repository.RecordRepository;
import com.example.demo.repository.StudentRepository;
import com.example.demo.repository.UserRepository;
import com.example.demo.service.AuthService;
import org.springframework.stereotype.Service;

import java.util.Base64;
import java.util.Optional;

@Service
public class AuthServiceImpl implements AuthService {

    /*@Autowired
    HttpServletRequest httpServletRequest;*/

    public final UserRepository userRepository;
    public final LectureRepository lectureRepository;
    public final RecordRepository recordRepository;
    public final StudentRepository studentRepository;

    public AuthServiceImpl(UserRepository userRepository, LectureRepository lectureRepository, RecordRepository recordRepository, StudentRepository studentRepository) {
        this.userRepository = userRepository;
        this.lectureRepository = lectureRepository;
        this.recordRepository = recordRepository;
        this.studentRepository = studentRepository;
    }


    @Override
    public Optional<User> login(String email, String password) {
        Optional<User> user = Optional.ofNullable(userRepository.findByEmailAndPassword(email, Base64.getEncoder().encodeToString(password.getBytes())));
        if(user.isPresent()) return user;
        return null;
    }

    /*@Override
    public void auth() {
        String token = httpServletRequest.getHeader("token");
        Optional<User> user = userRepository.findById(token);
        if(!user.isPresent()) throw new RuntimeException("Your mail or password is wrong!");
    }*/
}
