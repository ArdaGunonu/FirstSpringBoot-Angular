package com.example.demo.service.impl;

import com.example.demo.entity.Lecture;
import com.example.demo.entity.Record;
import com.example.demo.entity.Student;
import com.example.demo.entity.User;
import com.example.demo.repository.LectureRepository;
import com.example.demo.repository.RecordRepository;
import com.example.demo.repository.StudentRepository;
import com.example.demo.repository.UserRepository;
import com.example.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.servlet.HandlerInterceptor;

import java.util.Base64;
import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {

    public final UserRepository userRepository;
    public final LectureRepository lectureRepository;
    public final RecordRepository recordRepository;
    public final StudentRepository studentRepository;

    //START OF USER
    public UserServiceImpl(UserRepository userRepository, LectureRepository lectureRepository, RecordRepository recordRepository, StudentRepository studentRepository) {
        this.userRepository = userRepository;
        this.lectureRepository = lectureRepository;
        this.recordRepository = recordRepository;
        this.studentRepository = studentRepository;
    }

    @Override
    public User createUser(User user) {
        user.setPassword(Base64.getEncoder().encodeToString(user.getPassword().getBytes()));
        if(!user.getType().equals("student")){
            return userRepository.save(user);
        }
        User newUser = userRepository.save(user);
        Student newStudent = new Student();
        newStudent.setStudentId(user.getId());
        newStudent.setClassNumber(1);
        studentRepository.save(newStudent);
        return newUser;
    }

    @Override
    public List<User> getUsers() {
        return userRepository.findAll();
    }


    @Override
    public User getUser(String id) {
        return userRepository.findById(id).orElse(null);
    }

    @Override
    public List<User> getTeachers() {
        return  userRepository.findByType("teacher");
    }

    @Override
    public List<User> getStudents() {
        return userRepository.findByType("student");
    }


    @Override
    public String getType(String token) {
        return userRepository.findById(token).get().getType();
    }



    @Override
    public User updateUser(String id, User user) {
        Optional<User> resultUser = userRepository.findById(id);
        if(resultUser.isPresent()){
            if(user.getName() != null) resultUser.get().setName(user.getName());
            if(user.getLastname() != null) resultUser.get().setLastname(user.getLastname());
            if(user.getEmail() != null) resultUser.get().setEmail(user.getEmail());
            if(user.getPhone() != null) resultUser.get().setPhone(user.getPhone());
            if(user.getType() != null) resultUser.get().setType(user.getType());
            return userRepository.save(resultUser.get());
        }
        return null;
    }

    @Override
    public String changePassword(String id, String oldPassword, String newPassword) {
        Optional<User> resultUser = userRepository.findById(id);
        if(resultUser.isPresent() && resultUser.get().getPassword().equals(Base64.getEncoder().encodeToString(oldPassword.getBytes()))){
            if(newPassword == null ) return "This area can not be empty";
            else if(newPassword.equals(oldPassword)) return "New password can not be same with old password";
            else {
                resultUser.get().setPassword(Base64.getEncoder().encodeToString(newPassword.getBytes()));
                userRepository.save(resultUser.get());
                return "New password: " + newPassword;
            }
        }
        return "Wrong old password";
    }


    @Override
    public Boolean deleteUser(String id) {
        Optional<User> user = userRepository.findById(id);
        if(user.isPresent()){
            userRepository.deleteById(id);
            return true;
        }
        return false;
    }
    //END OF USER

    //START OF LECTURE
    @Override
    public Lecture createLecture(Lecture lecture) {
        if(!userRepository.findById(lecture.getTeacherId()).get().getType().equals("teacher")){
            return null;
        }
        return lectureRepository.save(lecture);
    }

    @Override
    public List<Lecture> getLectures() {
        return lectureRepository.findAll();
    }

    @Override
    public List<Lecture> getLecturesByTeacher(String id) {
        return lectureRepository.findByTeacherId(id);
    }

    @Override
    public Lecture updateLecture(String id, Lecture lecture) {
        Optional<Lecture> resultLecture = lectureRepository.findById(id);
        if(resultLecture.isPresent()){
            if(lecture.getName() != null) resultLecture.get().setName(lecture.getName());
            if(lecture.getTeacherId() != null) resultLecture.get().setTeacherId(lecture.getTeacherId());
            if(lecture.getCredit() != null)resultLecture.get().setCredit(lecture.getCredit());
            return lectureRepository.save(resultLecture.get());
        }
        return null;
    }

    @Override
    public Boolean deleteLecture(String id) {
        Optional<Lecture> lecture = lectureRepository.findById(id);
        if(lecture.isPresent()){
            lectureRepository.deleteById(id);
            return true;
        }
        return false;
    }
    //END OF LECTURE

    //START OF RECORD
    @Override
    public Record addRecord(Record record) {
        Optional<Record> recordControl = Optional.ofNullable(recordRepository.findByLectureIdAndStudentId(record.getLectureId(), record.getStudentId()));
        if(!userRepository.findById(record.getStudentId()).get().getType().equals("student") ||
                studentRepository.findByStudentId(record.getStudentId()).getClassNumber() == null ||
                recordControl.isPresent()) {
            return null;
        }
        return recordRepository.save(record);
    }

    @Override
    public List<Record> getRecordsByLecture(String id) {
        return recordRepository.findByLectureId(id);
    }

    @Override
    public List<Record> getRecordsByStudent(String id) {
        return recordRepository.findByStudentId(id);
    }

    @Override
    public Record updateGrade(String lectureId, String studentId, Record record) {
        Optional<Record> resultRecord = Optional.ofNullable(recordRepository.findByLectureIdAndStudentId(lectureId, studentId));
        if(resultRecord.isPresent()){
            resultRecord.get().setGrade(record.getGrade());
            return recordRepository.save(resultRecord.get());
        }
        return null;
    }


    @Override
    public Boolean deleteRecord(String id) {
        Optional<Record> record = recordRepository.findById(id);
        if(record.isPresent()){
            recordRepository.deleteById(id);
            return true;
        }
        return false;
    }

    @Override
    public Boolean deleteRecords() {
        recordRepository.deleteAll();
        return true;
    }


    //END OF RECORD

    //START OF STUDENT
    @Override
    public List<Student> updateGPA() {
        List<User> students = userRepository.findByType("student");
        for ( User user:students ) {
            Student student = studentRepository.findByStudentId(user.getId());
            if(recordRepository.findByStudentId(user.getId()).isEmpty()){continue;}
            Double GPA = 0.0;
            Integer credit = 0;
            List<Record> records = recordRepository.findByStudentId(user.getId());
            for ( Record record:records ) {
                if(record.getGrade() != null){
                    GPA += record.getGrade() * lectureRepository.findById(record.getLectureId()).get().getCredit();
                    credit += lectureRepository.findById(record.getLectureId()).get().getCredit();
                }
            }
            if(student.getClassNumber() != null){
                if(student.getClassNumber() == 1){
                    student.setGpa(GPA / credit);
                }
                else{
                    if(student.getGpa().isNaN()){
                        student.setClassNumber(student.getClassNumber() - 1);
                        break;
                    }
                    student.setGpa((student.getGpa() * (student.getClassNumber() - 1) + GPA / credit) / student.getClassNumber());
                }

                if(student.getClassNumber() < 4) student.setClassNumber(student.getClassNumber() + 1);
                else student.setClassNumber(null);
                if(!student.getGpa().isNaN()) studentRepository.save(student);
            }
        }
        //List<Record> records = recordRepository.findAll();
        recordRepository.deleteAll();
        return null;
    }
    //END OF STUDENT
}
