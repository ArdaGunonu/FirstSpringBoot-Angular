package com.example.demo.controller;

import com.example.demo.entity.User;
import com.example.demo.service.AuthService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/auth")
public class AuthController {



    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @GetMapping("/login")
    public ResponseEntity<Optional<User>> login(@RequestHeader("email") String email, @RequestHeader ("password") String password){
        Optional<User> userId = authService.login(email, password);
        return ResponseEntity.ok(userId);
    }
}
